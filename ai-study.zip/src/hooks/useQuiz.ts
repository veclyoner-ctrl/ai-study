import { useState, useCallback } from 'react';
import { Quiz, QuizQuestion } from '../types/quiz';

export const useQuiz = () => {
  const [quizHistory, setQuizHistory] = useState<Quiz[]>(() => {
    try {
      const saved = localStorage.getItem('ai-study-quiz-history');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateQuiz = useCallback(async (
    topic: string,
    subject: string,
    questionCount: number,
    timeLimit: number
  ): Promise<Quiz | null> => {
    setIsGenerating(true);
    setError(null);
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{
            role: 'user',
            content: `"${topic}" topic pe ${questionCount} short answer questions banao.

Sirf JSON respond karo, koi extra text nahi:
{
  "title": "Quiz ka title",
  "questions": [
    {
      "question": "Sawal text yahan",
      "correctAnswer": "Sahi jawab yahan (1-3 sentences)",
      "explanation": "Why this is correct (Roman Urdu mein explain karo)"
    }
  ]
}

Rules:
- Questions clear aur specific hon
- Short answers expected (1-3 sentences)
- Educational aur factual hon
- Roman Urdu + English mixed
- Exactly ${questionCount} questions`
          }],
          subject
        }),
      });

      if (!response.ok) throw new Error('Quiz generate nahi ho saka');
      const data = await response.json();

      let parsed: { title: string; questions: Array<{question: string; correctAnswer: string; explanation: string}> };
      try {
        const clean = data.response.replace(/```json|```/g, '').trim();
        parsed = JSON.parse(clean);
      } catch {
        throw new Error('Quiz format mein error aayi');
      }

      const quiz: Quiz = {
        id: Date.now().toString(),
        title: parsed.title || `${topic} Quiz`,
        topic,
        subject,
        timeLimit,
        totalQuestions: parsed.questions.length,
        createdAt: new Date().toISOString(),
        questions: parsed.questions.map((q, i) => ({
          id: `q_${i}`,
          question: q.question,
          correctAnswer: q.correctAnswer,
          explanation: q.explanation,
          subject,
        })),
      };

      return quiz;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error aayi');
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, []);

  const saveQuizResult = useCallback((quiz: Quiz) => {
    const updated = [quiz, ...quizHistory].slice(0, 20);
    setQuizHistory(updated);
    localStorage.setItem('ai-study-quiz-history', JSON.stringify(updated));
  }, [quizHistory]);

  return { quizHistory, isGenerating, error, generateQuiz, saveQuizResult };
};
