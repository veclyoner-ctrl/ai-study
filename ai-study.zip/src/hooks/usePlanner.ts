import { useState, useCallback } from 'react';
import { StudyTask } from '../types/planner';

export const usePlanner = () => {
  const [tasks, setTasks] = useState<StudyTask[]>(() => {
    try {
      const saved = localStorage.getItem('ai-study-tasks');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });

  const saveToStorage = useCallback((updated: StudyTask[]) => {
    localStorage.setItem('ai-study-tasks', JSON.stringify(updated));
    setTasks(updated);
  }, []);

  const addTask = useCallback((task: Omit<StudyTask, 'id' | 'createdAt' | 'isCompleted'>) => {
    const newTask: StudyTask = {
      ...task,
      id: Date.now().toString(),
      isCompleted: false,
      createdAt: new Date().toISOString(),
    };
    saveToStorage([...tasks, newTask]);
    return newTask;
  }, [tasks, saveToStorage]);

  const toggleComplete = useCallback((id: string) => {
    saveToStorage(tasks.map(t => t.id === id ? { ...t, isCompleted: !t.isCompleted } : t));
  }, [tasks, saveToStorage]);

  const deleteTask = useCallback((id: string) => {
    saveToStorage(tasks.filter(t => t.id !== id));
  }, [tasks, saveToStorage]);

  const getTasksForDate = useCallback((date: string) => {
    return tasks
      .filter(t => t.date === date)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [tasks]);

  const getTasksForWeek = useCallback((startDate: string) => {
    const start = new Date(startDate);
    const end = new Date(startDate);
    end.setDate(end.getDate() + 6);
    return tasks.filter(t => {
      const d = new Date(t.date);
      return d >= start && d <= end;
    });
  }, [tasks]);

  return { tasks, addTask, toggleComplete, deleteTask, getTasksForDate, getTasksForWeek };
};
