import { useState, useCallback } from 'react';
import { Note, NoteColor } from '../types/notes';

export const useNotes = () => {
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('ai-study-notes');
    return saved ? JSON.parse(saved) : [];
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const saveToStorage = useCallback((updatedNotes: Note[]) => {
    localStorage.setItem('ai-study-notes', JSON.stringify(updatedNotes));
    setNotes(updatedNotes);
  }, []);

  const generateNote = useCallback(async (topic: string, subject: string, color: NoteColor) => {
    setIsGenerating(true);
    setError(null);
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{
            role: 'user',
            content: `Is topic ke liye structured study notes banao: "${topic}"
            
Format bilkul aisa hona chahiye (JSON mein jawab do):
{
  "title": "Note ka title",
  "content": "Poori notes markdown format mein (headings, bullets, bold use karo)",
  "tags": ["tag1", "tag2", "tag3"]
}

Notes mein yeh hona chahiye:
- Main concepts clearly explain hon
- Important points bold hon
- Examples hon
- Key terms highlight hon
- Roman Urdu mein easy language use karo`
          }],
          subject,
          responseFormat: 'json'
        }),
      });
      if (!response.ok) throw new Error('Notes generate nahi ho sake');
      const data = await response.json();
      
      let parsed: { title: string; content: string; tags: string[] };
      try {
        const clean = data.response.replace(/```json|```/g, '').trim();
        parsed = JSON.parse(clean);
      } catch {
        parsed = {
          title: topic,
          content: data.response,
          tags: [subject]
        };
      }

      const newNote: Note = {
        id: Date.now().toString(),
        title: parsed.title || topic,
        content: parsed.content || data.response,
        subject,
        tags: parsed.tags || [subject],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        isPinned: false,
        color,
      };
      const updated = [newNote, ...notes];
      saveToStorage(updated);
      return newNote;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error aayi');
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, [notes, saveToStorage]);

  const deleteNote = useCallback((id: string) => {
    saveToStorage(notes.filter(n => n.id !== id));
  }, [notes, saveToStorage]);

  const togglePin = useCallback((id: string) => {
    saveToStorage(notes.map(n => n.id === id ? { ...n, isPinned: !n.isPinned } : n));
  }, [notes, saveToStorage]);

  const updateNote = useCallback((id: string, content: string) => {
    saveToStorage(notes.map(n => n.id === id ? { ...n, content, updatedAt: new Date().toISOString() } : n));
  }, [notes, saveToStorage]);

  return { notes, isGenerating, error, generateNote, deleteNote, togglePin, updateNote };
};
