import { useState, useCallback, useEffect } from 'react';
import { Badge, StudyStreak } from '../types/planner';

const BADGE_DEFINITIONS: Badge[] = [
  { id: 'first_note', name: 'Note Master', description: 'Pehli note banao', icon: '📝', isEarned: false, condition: 'Create 1 note' },
  { id: 'five_notes', name: 'Note Ninja', description: '5 notes banao', icon: '📚', isEarned: false, condition: 'Create 5 notes' },
  { id: 'first_quiz', name: 'Quiz Starter', description: 'Pehla quiz do', icon: '❓', isEarned: false, condition: 'Complete 1 quiz' },
  { id: 'quiz_ace', name: 'Quiz Ace', description: 'Quiz mein 90%+ score karo', icon: '🏆', isEarned: false, condition: 'Score 90%+ in a quiz' },
  { id: 'first_flashcard', name: 'Card Maker', description: 'Pehla flashcard deck banao', icon: '🃏', isEarned: false, condition: 'Create 1 flashcard deck' },
  { id: 'streak_3', name: '3-Day Streak', description: '3 din lagatar parho', icon: '🔥', isEarned: false, condition: '3 day study streak' },
  { id: 'streak_7', name: 'Week Warrior', description: '7 din lagatar parho', icon: '⚡', isEarned: false, condition: '7 day study streak' },
  { id: 'streak_30', name: 'Month Master', description: '30 din lagatar parho', icon: '👑', isEarned: false, condition: '30 day study streak' },
  { id: 'first_research', name: 'Researcher', description: 'Pehli research karo', icon: '🔍', isEarned: false, condition: 'Complete 1 research' },
  { id: 'task_10', name: 'Planner Pro', description: '10 tasks complete karo', icon: '✅', isEarned: false, condition: 'Complete 10 tasks' },
  { id: 'all_subjects', name: 'All-Rounder', description: 'Sab subjects mein kaam karo', icon: '🌟', isEarned: false, condition: 'Use all 8 subjects' },
  { id: 'night_owl', name: 'Night Owl', description: 'Raat 10 baje ke baad parho', icon: '🦉', isEarned: false, condition: 'Study after 10 PM' },
];

export const useGamification = () => {
  const [badges, setBadges] = useState<Badge[]>(() => {
    try {
      const saved = localStorage.getItem('ai-study-badges');
      if (saved) {
        const savedBadges: Badge[] = JSON.parse(saved);
        return BADGE_DEFINITIONS.map(def => {
          const saved_b = savedBadges.find(b => b.id === def.id);
          return saved_b ? { ...def, isEarned: saved_b.isEarned, earnedAt: saved_b.earnedAt } : def;
        });
      }
    } catch { }
    return BADGE_DEFINITIONS;
  });

  const [streak, setStreak] = useState<StudyStreak>(() => {
    try {
      const saved = localStorage.getItem('ai-study-streak');
      return saved ? JSON.parse(saved) : {
        currentStreak: 0, longestStreak: 0,
        lastStudyDate: '', totalStudyDays: 0
      };
    } catch {
      return { currentStreak: 0, longestStreak: 0, lastStudyDate: '', totalStudyDays: 0 };
    }
  });

  const [newBadge, setNewBadge] = useState<Badge | null>(null);

  const earnBadge = useCallback((badgeId: string) => {
    setBadges(prev => {
      const badge = prev.find(b => b.id === badgeId);
      if (!badge || badge.isEarned) return prev;
      const updated = prev.map(b => b.id === badgeId
        ? { ...b, isEarned: true, earnedAt: new Date().toISOString() }
        : b
      );
      localStorage.setItem('ai-study-badges', JSON.stringify(updated));
      setNewBadge({ ...badge, isEarned: true, earnedAt: new Date().toISOString() });
      setTimeout(() => setNewBadge(null), 4000);
      return updated;
    });
  }, []);

  const updateStreak = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    setStreak(prev => {
      if (prev.lastStudyDate === today) return prev;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];
      const newStreak = prev.lastStudyDate === yesterdayStr
        ? prev.currentStreak + 1
        : 1;
      const updated: StudyStreak = {
        currentStreak: newStreak,
        longestStreak: Math.max(newStreak, prev.longestStreak),
        lastStudyDate: today,
        totalStudyDays: prev.totalStudyDays + 1,
      };
      localStorage.setItem('ai-study-streak', JSON.stringify(updated));
      if (newStreak >= 3) earnBadge('streak_3');
      if (newStreak >= 7) earnBadge('streak_7');
      if (newStreak >= 30) earnBadge('streak_30');
      return updated;
    });
  }, [earnBadge]);

  const checkBadges = useCallback(() => {
    try {
      const notes = JSON.parse(localStorage.getItem('ai-study-notes') || '[]');
      const quizzes = JSON.parse(localStorage.getItem('ai-study-quiz-history') || '[]');
      const flashcards = JSON.parse(localStorage.getItem('ai-study-flashcards') || '[]');
      const research = JSON.parse(localStorage.getItem('ai-study-research') || '[]');
      const tasks = JSON.parse(localStorage.getItem('ai-study-tasks') || '[]');
      const completedTasks = tasks.filter((t: { isCompleted: boolean }) => t.isCompleted);

      if (notes.length >= 1) earnBadge('first_note');
      if (notes.length >= 5) earnBadge('five_notes');
      if (quizzes.length >= 1) earnBadge('first_quiz');
      if (quizzes.some((q: { score?: number; totalQuestions: number }) =>
        q.score && (q.score / q.totalQuestions) >= 0.9)) earnBadge('quiz_ace');
      if (flashcards.length >= 1) earnBadge('first_flashcard');
      if (research.length >= 1) earnBadge('first_research');
      if (completedTasks.length >= 10) earnBadge('task_10');

      const hour = new Date().getHours();
      if (hour >= 22 || hour < 4) earnBadge('night_owl');

      const allSubjects = ['physics', 'chemistry', 'mathematics', 'biology', 'english', 'history', 'computer', 'general'];
      const usedSubjects = new Set([
        ...notes.map((n: { subject: string }) => n.subject),
        ...quizzes.map((q: { subject: string }) => q.subject),
        ...flashcards.map((f: { subject: string }) => f.subject),
      ]);
      if (allSubjects.every(s => usedSubjects.has(s))) earnBadge('all_subjects');
    } catch { }
  }, [earnBadge]);

  useEffect(() => {
    updateStreak();
    checkBadges();
  }, []);

  return { badges, streak, newBadge, earnBadge, checkBadges, updateStreak };
};
