import { useState, useCallback } from 'react';
import { FlashcardDeck, Flashcard } from '../types/quiz';

export const useFlashcards = () => {
  const [decks, setDecks] = useState<FlashcardDeck[]>(() => {
    try {
      const saved = localStorage.getItem('ai-study-flashcards');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const saveToStorage = useCallback((updated: FlashcardDeck[]) => {
    localStorage.setItem('ai-study-flashcards', JSON.stringify(updated));
    setDecks(updated);
  }, []);

  const generateDeck = useCallback(async (
    topic: string,
    subject: string,
    cardCount: number
  ): Promise<FlashcardDeck | null> => {
    setIsGenerating(true);
    setError(null);
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{
            role: 'user',
            content: `"${topic}" ke liye ${cardCount} flashcards banao.

Sirf JSON respond karo:
{
  "title": "Deck ka title",
  "cards": [
    {
      "front": "Question ya term (short)",
      "back": "Answer ya definition (clear aur concise)"
    }
  ]
}

Rules:
- Front: short question ya important term
- Back: clear answer ya definition
- Roman Urdu + English mixed
- Exactly ${cardCount} cards`
          }],
          subject
        }),
      });

      if (!response.ok) throw new Error('Flashcards generate nahi ho sake');
      const data = await response.json();

      let parsed: { title: string; cards: Array<{front: string; back: string}> };
      try {
        const clean = data.response.replace(/```json|```/g, '').trim();
        parsed = JSON.parse(clean);
      } catch {
        throw new Error('Flashcard format error');
      }

      const deck: FlashcardDeck = {
        id: Date.now().toString(),
        title: parsed.title || `${topic} Flashcards`,
        topic,
        subject,
        createdAt: new Date().toISOString(),
        cards: parsed.cards.map((c, i) => ({
          id: `card_${i}`,
          front: c.front,
          back: c.back,
          subject,
          topic,
          isKnown: false,
          reviewCount: 0,
          createdAt: new Date().toISOString(),
        })),
      };

      saveToStorage([deck, ...decks]);
      return deck;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error aayi');
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, [decks, saveToStorage]);

  const markCard = useCallback((deckId: string, cardId: string, isKnown: boolean) => {
    saveToStorage(decks.map(d => d.id === deckId ? {
      ...d,
      cards: d.cards.map(c => c.id === cardId ? {
        ...c, isKnown, reviewCount: c.reviewCount + 1
      } : c)
    } : d));
  }, [decks, saveToStorage]);

  const deleteDeck = useCallback((deckId: string) => {
    saveToStorage(decks.filter(d => d.id !== deckId));
  }, [decks, saveToStorage]);

  return { decks, isGenerating, error, generateDeck, markCard, deleteDeck };
};
