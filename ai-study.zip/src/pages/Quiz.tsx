import { useState, useEffect } from 'react';
import { useQuiz } from '../hooks/useQuiz';
import { SUBJECTS } from '../types/notes';
import { Quiz } from '../types/quiz';

type QuizState = 'setup' | 'active' | 'result';

export default function QuizPage() {
  const { isGenerating, generateQuiz, saveQuizResult, quizHistory } = useQuiz();
  const [state, setState] = useState<QuizState>('setup');
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0].value);
  const [questionCount, setQuestionCount] = useState(5);
  const [timeLimit, setTimeLimit] = useState(10);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentIdx, setCurrentIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (state === 'active' && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
      return () => clearInterval(timer);
    } else if (state === 'active' && timeLeft === 0) {
      finishQuiz();
    }
  }, [state, timeLeft]);

  const startQuiz = async () => {
    const newQuiz = await generateQuiz(topic, subject, questionCount, timeLimit);
    if (newQuiz) {
      setQuiz(newQuiz);
      setTimeLeft(timeLimit * 60);
      setState('active');
    }
  };

  const finishQuiz = async () => {
    if (!quiz) return;
    
    // Evaluate answers with AI (simplified logic here)
    const completedQuiz = { ...quiz, completedAt: new Date().toISOString() };
    saveQuizResult(completedQuiz);
    setQuiz(completedQuiz);
    setState('result');
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Quiz Generator</h2>
      {state === 'setup' && (
        <div className="space-y-4">
          <input className="border p-2 rounded w-full" placeholder="Kaunsa topic ka quiz chahiye?" value={topic} onChange={e => setTopic(e.target.value)} />
          <select className="border p-2 rounded w-full" value={subject} onChange={e => setSubject(e.target.value)}>
            {SUBJECTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <div className="flex gap-2">
            <label>Question Count: {questionCount}</label>
            <input type="range" min="3" max="15" value={questionCount} onChange={e => setQuestionCount(Number(e.target.value))} />
          </div>
          <button className="bg-blue-900 text-white p-2 rounded w-full" onClick={startQuiz} disabled={isGenerating}>
            {isGenerating ? 'Questions ban rahe hain...' : 'Quiz Banao'}
          </button>
        </div>
      )}
      
      {state === 'active' && quiz && (
        <div className="space-y-4">
          <div className="flex justify-between font-bold">
            <span>Q: {currentIdx + 1}/{quiz.totalQuestions}</span>
            <span className={timeLeft < 60 ? 'text-red-500' : ''}>⏱ {Math.floor(timeLeft/60)}:{String(timeLeft%60).padStart(2,'0')}</span>
          </div>
          <p className="text-lg">{quiz.questions[currentIdx].question}</p>
          <textarea className="w-full border p-2 rounded" rows={3} placeholder="Apna jawab yahan likho..." 
            onChange={e => setAnswers({...answers, [quiz.questions[currentIdx].id]: e.target.value})} />
          <div className="flex gap-2">
            <button className="bg-gray-200 p-2 rounded" onClick={() => setCurrentIdx(Math.max(0, currentIdx-1))}>Prev</button>
            <button className="bg-blue-900 text-white p-2 rounded flex-1" onClick={() => currentIdx === quiz.totalQuestions - 1 ? finishQuiz() : setCurrentIdx(currentIdx+1)}>
                {currentIdx === quiz.totalQuestions - 1 ? 'Submit' : 'Next'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
