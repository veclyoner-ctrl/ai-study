import { useState } from 'react';
import { usePlanner } from '../hooks/usePlanner';
import { SUBJECTS } from '../types/notes';
import { Plus, Trash2, CheckCircle2, Circle } from 'lucide-react';

export default function Planner() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const { getTasksForDate, addTask, toggleComplete, deleteTask } = usePlanner();
  const tasks = getTasksForDate(selectedDate);

  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0].value);
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');

  const handleAddTask = () => {
    addTask({ title, subject, date: selectedDate, startTime, endTime, priority });
    setIsAdding(false);
    setTitle('');
  };

  return (
    <div className="flex p-6 gap-6 h-screen">
      <div className="w-64 border p-4">
        <h3 className="font-bold mb-4">{new Date(selectedDate).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</h3>
        {/* Simplified Calendar: Show current week */}
        <div className="grid grid-cols-7 gap-2">
            {['S','M','T','W','T','F','S'].map(d => <div key={d} className="font-bold text-center">{d}</div>)}
            {[...Array(7)].map((_, i) => {
                const d = new Date(); d.setDate(d.getDate() - d.getDay() + i);
                const ds = d.toISOString().split('T')[0];
                return <button key={i} className={`p-2 rounded ${selectedDate === ds ? 'bg-blue-900 text-white' : ''}`} onClick={() => setSelectedDate(ds)}>{d.getDate()}</button>;
            })}
        </div>
      </div>
      <div className="flex-1">
        <div className="flex justify-between mb-4">
            <h2 className="text-xl font-bold">{new Date(selectedDate).toDateString()} ke Tasks</h2>
            <button className="bg-blue-900 text-white p-2 rounded" onClick={() => setIsAdding(true)}><Plus size={20}/></button>
        </div>
        {isAdding && (
            <div className="bg-gray-100 p-4 rounded mb-4">
                <input className="w-full mb-2 p-2" placeholder="Task title" value={title} onChange={e => setTitle(e.target.value)}/>
                <select className="mb-2 p-2" value={subject} onChange={e => setSubject(e.target.value)}>{SUBJECTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}</select>
                <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} />
                <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} />
                <button className="bg-green-600 text-white p-2 rounded ml-2" onClick={handleAddTask}>Save</button>
            </div>
        )}
        <div className="space-y-2">
            {tasks.map(t => (
                <div key={t.id} className="flex items-center gap-4 p-2 border rounded">
                    <button onClick={() => toggleComplete(t.id)}>{t.isCompleted ? <CheckCircle2 className="text-green-600"/> : <Circle/>}</button>
                    <span className={t.isCompleted ? 'line-through text-gray-500' : ''}>{t.title} ({t.startTime}-{t.endTime})</span>
                    <button className="ml-auto" onClick={() => deleteTask(t.id)}><Trash2 size={16} /></button>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
}
