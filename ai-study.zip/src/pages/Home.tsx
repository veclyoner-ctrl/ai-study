import { motion } from 'motion/react';
import { Brain, BookOpen, HelpCircle, FileText, Calendar, LayoutDashboard } from 'lucide-react';

export function Home() {
  const features = [
    { title: 'AI Assistant', icon: Brain },
    { title: 'Smart Notes', icon: BookOpen },
    { title: 'Quiz Generator', icon: HelpCircle },
    { title: 'Flashcards', icon: FileText },
    { title: 'Study Planner', icon: Calendar },
    { title: 'Progress Dashboard', icon: LayoutDashboard },
  ];

  return (
    <div className="flex-1 bg-gradient-to-br from-blue-700 to-blue-900 p-8 text-white">
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16 text-center"
      >
        <h1 className="mb-4 text-5xl font-bold">AI ke sath Smarter Study karo</h1>
        <p className="mb-8 text-xl">Tumhari parhai ka naya andaaz</p>
        <div className="flex justify-center gap-4">
          <button className="rounded-full bg-yellow-400 px-8 py-3 font-bold text-blue-900">Start Learning</button>
          <button className="rounded-full border border-white px-8 py-3 font-bold">Explore Features</button>
        </div>
      </motion.section>

      <section className="mb-16 grid grid-cols-1 gap-6 md:grid-cols-3">
        {[
          { label: 'Students', value: '10,000+' },
          { label: 'Subjects', value: '50+' },
          { label: 'AI Queries', value: '1M+' },
        ].map(stat => (
          <div key={stat.label} className="rounded-xl bg-white/10 p-6 text-center shadow-lg">
            <div className="text-3xl font-bold text-yellow-400">{stat.value}</div>
            <div className="text-sm">{stat.label}</div>
          </div>
        ))}
      </section>

      <section className="grid grid-cols-1 gap-6 md:grid-cols-3 lg:grid-cols-3">
        {features.map(feature => (
          <motion.div
            key={feature.title}
            whileHover={{ scale: 1.05 }}
            className="rounded-xl border border-transparent bg-white/10 p-6 hover:border-yellow-400"
          >
            <feature.icon size={40} className="mb-4 text-yellow-400" />
            <h3 className="text-xl font-bold">{feature.title}</h3>
          </motion.div>
        ))}
      </section>
      
      <footer className="mt-16 text-center">
        <p>&copy; 2026 AI STUDY. Sahi parhai, sahi raasta.</p>
      </footer>
    </div>
  );
}
