export default function Dashboard() {
  const notes = JSON.parse(localStorage.getItem('ai-study-notes') || '[]');
  const quizzes = JSON.parse(localStorage.getItem('ai-study-quiz-history') || '[]');
  const streak = JSON.parse(localStorage.getItem('ai-study-streak') || '{"currentStreak":0}');
  const badges = JSON.parse(localStorage.getItem('ai-study-badges') || '[]');

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Progress Dashboard</h2>
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="p-4 border rounded shadow">Total Streak: {streak.currentStreak} days</div>
        <div className="p-4 border rounded shadow">Notes: {notes.length}</div>
        <div className="p-4 border rounded shadow">Quizzes: {quizzes.length}</div>
        <div className="p-4 border rounded shadow">Badges: {badges.filter((b: any) => b.isEarned).length}</div>
      </div>
      <div className="grid grid-cols-2 gap-6">
        <div className="p-4 border rounded shadow">
            <h3 className="font-bold mb-4">Weekly Activity</h3>
            <div className="flex items-end gap-2 h-40">
                {[...Array(7)].map((_, i) => <div key={i} className="bg-blue-900 w-10" style={{ height: `${Math.random() * 100}%` }}></div>)}
            </div>
        </div>
        <div className="p-4 border rounded shadow">
            <h3 className="font-bold mb-4">Badges</h3>
            <div className="grid grid-cols-4 gap-2">
                {badges.map((b: any) => <div key={b.id} className={`p-2 rounded text-center ${b.isEarned ? 'bg-yellow-200' : 'bg-gray-200'}`}>{b.icon}</div>)}
            </div>
        </div>
      </div>
    </div>
  );
}
