import { useState } from 'react';
import { useNotes } from '../hooks/useNotes';
import { NOTE_COLORS, SUBJECTS, NoteColor } from '../types/notes';
import { BookOpen, Trash2, Pin, Download, Edit2 } from 'lucide-react';
import { exportNoteToPDF } from '../utils/pdfExport';

export default function Notes() {
  const { notes, isGenerating, generateNote, deleteNote, togglePin } = useNotes();
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0].value);
  const [color, setColor] = useState<NoteColor>('blue');

  return (
    <div className="flex h-screen p-6 gap-6">
      <div className="w-[300px] flex flex-col gap-4">
        <h2 className="text-xl font-bold flex items-center gap-2"><BookOpen/> Smart Notes</h2>
        <input className="w-full p-2 border rounded" placeholder="Topic likho..." value={topic} onChange={e => setTopic(e.target.value)}/>
        <select className="w-full p-2 border rounded" value={subject} onChange={e => setSubject(e.target.value)}>
          {SUBJECTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <div className="flex gap-2">
          {Object.keys(NOTE_COLORS).map(c => (
            <button key={c} className="w-8 h-8 rounded-full border-2" style={{ backgroundColor: NOTE_COLORS[c as NoteColor] }} onClick={() => setColor(c as NoteColor)}/>
          ))}
        </div>
        <button className="w-full p-2 bg-blue-900 text-white rounded" onClick={() => generateNote(topic, subject, color)} disabled={isGenerating}>
          {isGenerating ? 'Generating...' : 'AI se Notes Banao'}
        </button>
      </div>

      <div className="flex-1 grid grid-cols-auto-fill gap-4 overflow-y-auto">
        {notes.map(note => (
          <div key={note.id} className="p-4 rounded shadow-md border" style={{ backgroundColor: NOTE_COLORS[note.color] }}>
            <div className="flex justify-between">
              <button onClick={() => togglePin(note.id)}><Pin size={16} className={note.isPinned ? 'fill-black' : ''}/></button>
              <button onClick={() => deleteNote(note.id)}><Trash2 size={16}/></button>
            </div>
            <h3 className="font-bold truncate">{note.title}</h3>
            <p className="text-sm line-clamp-4">{note.content}</p>
            <div className="flex gap-1 mt-2">
              {note.tags.map(tag => <span key={tag} className="text-xs bg-yellow-200 px-1 rounded">{tag}</span>)}
            </div>
            <button onClick={() => exportNoteToPDF(note.title, note.content, note.subject)}><Download size={16}/></button>
          </div>
        ))}
      </div>
    </div>
  );
}
