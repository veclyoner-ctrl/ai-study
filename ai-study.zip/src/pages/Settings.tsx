import { useState } from 'react';
import { usePlanner } from '../hooks/usePlanner';
import { useGamification } from '../hooks/useGamification';
import { User, Download, Trash2, Moon, Sun, Monitor, AlertTriangle } from 'lucide-react';

export default function Settings() {
  const [name, setName] = useState(localStorage.getItem('userName') || 'User');
  const { badges } = useGamification();

  const exportData = () => {
    const data = {
      notes: localStorage.getItem('ai-study-notes'),
      quiz: localStorage.getItem('ai-study-quiz-history'),
      flashcards: localStorage.getItem('ai-study-flashcards'),
      tasks: localStorage.getItem('ai-study-tasks'),
    };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ai-study-data.json';
    a.click();
  };

  const clearData = () => {
    if (confirm('Kya aap sure hain? Sab data delete ho jayega.')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-8">
      <h2 className="text-2xl font-bold">Settings</h2>
      
      <section className="border p-4 rounded-lg">
        <h3 className="font-bold mb-4">Profile</h3>
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-blue-900 text-yellow-400 rounded-full flex items-center justify-center font-bold text-2xl">{name[0]}</div>
          <input className="border p-2 rounded" value={name} onChange={e => setName(e.target.value)} />
          <button className="bg-blue-900 text-white p-2 rounded" onClick={() => localStorage.setItem('userName', name)}>Save</button>
        </div>
      </section>

      <section className="border p-4 rounded-lg">
        <h3 className="font-bold mb-4">Appearance</h3>
        <div className="flex gap-4">
          <button className="p-4 border rounded flex flex-col items-center"><Sun size={24}/>Light</button>
          <button className="p-4 border rounded flex flex-col items-center"><Moon size={24}/>Dark</button>
          <button className="p-4 border rounded flex flex-col items-center"><Monitor size={24}/>System</button>
        </div>
      </section>

      <section className="border p-4 rounded-lg">
        <h3 className="font-bold mb-4 text-red-600">Danger Zone</h3>
        <button className="bg-red-100 text-red-700 p-2 rounded flex items-center gap-2" onClick={clearData}>
          <Trash2 size={16}/> Clear All Data
        </button>
        <button className="bg-blue-100 text-blue-700 p-2 rounded flex items-center gap-2 mt-2" onClick={exportData}>
          <Download size={16}/> Export Data
        </button>
      </section>
    </div>
  );
}
