export function Notes() { return <div className="p-8">Notes</div>; }
export function Planner() { return <div className="p-8">Planner</div>; }
export function Dashboard() { return <div className="p-8">Dashboard</div>; }
export function NotFound() { 
  return (
    <div className="p-8 text-center text-2xl flex flex-col items-center justify-center h-full">
      <h1 className="text-9xl font-bold text-blue-900 animate-bounce">404</h1>
      <p className="mb-4">Yeh page nahi mila!</p>
      <a href="/" className="bg-blue-900 text-white px-6 py-2 rounded-lg">Home pe jao</a>
    </div>
  ); 
}
