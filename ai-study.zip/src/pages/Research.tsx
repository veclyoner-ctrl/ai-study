import { useState } from 'react';
import { SUBJECTS } from '../types/notes';
import { Search } from 'lucide-react';

export default function Research() {
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0].value);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const performResearch = async () => {
    setLoading(true);
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [{
            role: 'user',
            content: `Topic: "${topic}" ke baare mein detailed research karo. JSON format mein jawab do: { "summary": "...", "keyPoints": ["..."], "conclusion": "..." }`
        }],
        subject
      }),
    });
    const data = await response.json();
    setResult(JSON.parse(data.response.replace(/```json|```/g, '').trim()));
    setLoading(false);
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold">Research Helper</h2>
      <div className="flex gap-2 my-4">
        <input className="flex-1 p-2 border rounded" placeholder="Deep research..." value={topic} onChange={e => setTopic(e.target.value)}/>
        <select className="p-2 border rounded" value={subject} onChange={e => setSubject(e.target.value)}>
          {SUBJECTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <button className="p-2 bg-blue-900 text-white rounded" onClick={performResearch}>Research Karo</button>
      </div>
      {loading && <p>Researching...</p>}
      {result && (
        <div className="p-6 border rounded shadow mt-4">
          <h3 className="font-bold text-xl">{topic}</h3>
          <p className="my-2">{result.summary}</p>
          <ul className="list-disc ml-4">
            {result.keyPoints.map((p: string, i: number) => <li key={i}>{p}</li>)}
          </ul>
          <p className="mt-4 font-bold">{result.conclusion}</p>
        </div>
      )}
    </div>
  );
}
