import { useState } from 'react';
import { motion } from 'motion/react';
import { Send, Brain } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export function AiAssistant() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [subject, setSubject] = useState('General Study');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: 'user', content: input } as Message];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newMessages, subject }),
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = 'Failed to get response';
        try {
            const errorJson = JSON.parse(errorText);
            errorMessage = errorJson.error || errorMessage;
        } catch {
            errorMessage = `Server Error (${response.status})`;
        }
        throw new Error(errorMessage);
      }
      
      const data = await response.json();
      setMessages([...newMessages, { role: 'assistant', content: data.response }]);
    } catch (error) {
      console.error(error);
      setMessages([...newMessages, { role: 'assistant', content: `Error: ${error instanceof Error ? error.message : 'Something went wrong'}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-full flex-col p-6">
      <h2 className="mb-6 text-2xl font-bold dark:text-white">AI Study Assistant</h2>
      
      <div className="mb-4">
        <select 
          value={subject} 
          onChange={(e) => setSubject(e.target.value)}
          className="rounded-lg border p-2 dark:bg-gray-800 dark:text-white"
        >
          <option>General Study</option>
          <option>Mathematics</option>
          <option>Science</option>
          <option>History</option>
        </select>
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto rounded-xl border p-4 dark:border-gray-700">
        {messages.map((m, i) => (
          <motion.div 
            key={i} 
            initial={{ opacity: 0, y: 10 }} 
            animate={{ opacity: 1, y: 0 }}
            className={`p-3 rounded-lg ${m.role === 'user' ? 'bg-blue-100 ml-auto' : 'bg-gray-100 dark:bg-gray-800'}`}
          >
            {m.content}
          </motion.div>
        ))}
        {loading && <div className="text-gray-500">Study AI is thinking...</div>}
      </div>

      <div className="mt-4 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Ask a question..."
          className="flex-1 rounded-lg border p-2 dark:bg-gray-800 dark:text-white"
        />
        <button 
            onClick={sendMessage}
            className="rounded-lg bg-blue-700 p-2 text-white hover:bg-blue-800"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
}
