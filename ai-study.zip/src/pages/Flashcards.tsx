import { useState, useEffect } from 'react';
import { useFlashcards } from '../hooks/useFlashcards';
import { SUBJECTS } from '../types/notes';
import { motion } from 'motion/react';

type FlashcardView = 'library' | 'study';

export default function FlashcardsPage() {
  const { isGenerating, decks, generateDeck } = useFlashcards();
  const [view, setView] = useState<FlashcardView>('library');
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0].value);
  const [activeDeck, setActiveDeck] = useState<any>(null);
  const [cardIndex, setCardIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
        if (e.code === 'Space') setFlipped(!flipped);
        if (e.code === 'ArrowRight') setCardIndex((c) => (c + 1) % activeDeck.cards.length);
        if (e.code === 'ArrowLeft') setCardIndex((c) => (c - 1 + activeDeck.cards.length) % activeDeck.cards.length);
    };
    if (view === 'study') window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [view, flipped, activeDeck]);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Flashcard Maker</h2>
      {view === 'library' ? (
        <div className="flex gap-6">
            <div className="w-72 space-y-4">
                <input className="border p-2 rounded w-full" placeholder="Topic..." value={topic} onChange={e => setTopic(e.target.value)} />
                <select className="border p-2 rounded w-full" value={subject} onChange={e => setSubject(e.target.value)}>
                    {SUBJECTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                </select>
                <button className="bg-blue-900 text-white p-2 rounded w-full" onClick={() => generateDeck(topic, subject, 10)} disabled={isGenerating}>
                    {isGenerating ? 'Cards ban rahe hain...' : 'Flashcards Banao'}
                </button>
            </div>
            <div className="flex-1 grid grid-cols-2 gap-4">
                {decks.map(d => (
                    <div key={d.id} className="border p-4 rounded shadow hover:shadow-lg cursor-pointer" onClick={() => { setActiveDeck(d); setView('study'); }}>
                        <h3 className="font-bold">{d.title}</h3>
                        <p className="text-sm">{d.cards.length} cards</p>
                    </div>
                ))}
            </div>
        </div>
      ) : (
        <div className="flex flex-col items-center">
          <div className="perspective-1000 w-80 h-48 cursor-pointer" onClick={() => setFlipped(!flipped)}>
              <motion.div className="w-full h-full relative transition-transform duration-500 transform-style-3d" animate={{ rotateY: flipped ? 180 : 0 }}>
                <div className="absolute w-full h-full backface-hidden bg-blue-900 text-white flex items-center justify-center p-4 rounded shadow-lg">
                    {activeDeck.cards[cardIndex].front}
                </div>
                <div className="absolute w-full h-full backface-hidden bg-blue-100 text-blue-900 flex items-center justify-center p-4 rounded shadow-lg transform rotate-y-180">
                    {activeDeck.cards[cardIndex].back}
                </div>
              </motion.div>
          </div>
          <div className="mt-8 flex gap-4">
            <button className="bg-gray-200 p-2 rounded" onClick={() => setView('library')}>Back to Library</button>
            <button className="bg-green-600 text-white p-2 rounded">Pata Hai ✓</button>
            <button className="bg-red-600 text-white p-2 rounded">Nahi Pata ✗</button>
          </div>
        </div>
      )}
    </div>
  );
}
