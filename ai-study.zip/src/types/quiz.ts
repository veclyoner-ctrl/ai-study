export interface QuizQuestion {
  id: string;
  question: string;
  correctAnswer: string;
  userAnswer?: string;
  isCorrect?: boolean;
  explanation: string;
  subject: string;
}

export interface Quiz {
  id: string;
  title: string;
  topic: string;
  subject: string;
  questions: QuizQuestion[];
  score?: number;
  totalQuestions: number;
  completedAt?: string;
  createdAt: string;
  timeLimit: number; // minutes
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  subject: string;
  topic: string;
  isKnown: boolean;
  reviewCount: number;
  createdAt: string;
}

export interface FlashcardDeck {
  id: string;
  title: string;
  topic: string;
  subject: string;
  cards: Flashcard[];
  createdAt: string;
  lastStudied?: string;
}
