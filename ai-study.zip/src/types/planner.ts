export interface StudyTask {
  id: string;
  title: string;
  subject: string;
  date: string; // ISO date string YYYY-MM-DD
  startTime: string; // HH:MM
  endTime: string; // HH:MM
  isCompleted: boolean;
  priority: 'low' | 'medium' | 'high';
  notes?: string;
  createdAt: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string; // emoji
  earnedAt?: string;
  isEarned: boolean;
  condition: string; // human readable condition
}

export interface StudyStreak {
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string;
  totalStudyDays: number;
}

export interface DailyProgress {
  date: string;
  studyMinutes: number;
  tasksCompleted: number;
  quizzesTaken: number;
  notesCreated: number;
  flashcardsReviewed: number;
}
