export interface Note {
  id: string;
  title: string;
  content: string;
  subject: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  isPinned: boolean;
  color: NoteColor;
}

export type NoteColor = 'blue' | 'yellow' | 'green' | 'purple' | 'red';

export interface ResearchResult {
  id: string;
  topic: string;
  summary: string;
  keyPoints: string[];
  conclusion: string;
  subject: string;
  createdAt: string;
}

export const NOTE_COLORS: Record<NoteColor, string> = {
  blue: '#E8EAF6',
  yellow: '#FFFDE7',
  green: '#E8F5E9',
  purple: '#F3E5F5',
  red: '#FFEBEE',
};

export const SUBJECTS = [
  { value: 'general', label: 'General', icon: '📚' },
  { value: 'physics', label: 'Physics', icon: '⚡' },
  { value: 'chemistry', label: 'Chemistry', icon: '🧪' },
  { value: 'mathematics', label: 'Mathematics', icon: '📐' },
  { value: 'biology', label: 'Biology', icon: '🔬' },
  { value: 'english', label: 'English', icon: '📝' },
  { value: 'history', label: 'History', icon: '🏛️' },
  { value: 'computer', label: 'Computer Science', icon: '💻' },
];
