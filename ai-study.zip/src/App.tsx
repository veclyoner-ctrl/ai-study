import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { ProfileModal } from './components/ProfileModal';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Home } from './pages/Home';
import { AiAssistant } from './pages/AiAssistant';
import Notes from './pages/Notes';
import Research from './pages/Research';
import QuizPage from './pages/Quiz';
import FlashcardsPage from './pages/Flashcards';
import Planner from './pages/Planner';
import Dashboard from './pages/Dashboard';
import { NotFound } from './pages/PlaceholderPages';
import { useState, useEffect } from 'react';
import { useGamification } from './hooks/useGamification';
import BadgeNotification from './components/BadgeNotification';
import LoadingScreen from './components/LoadingScreen';

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <div key={location.pathname} className="page-wrapper flex-1">
      <Routes location={location}>
        <Route path="/" element={<Home />} />
        <Route path="/ai-assistant" element={<AiAssistant />} />
        <Route path="/notes" element={<Notes />} />
        <Route path="/research" element={<Research />} />
        <Route path="/quiz" element={<QuizPage />} />
        <Route path="/flashcards" element={<FlashcardsPage />} />
        <Route path="/planner" element={<Planner />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}

export default function App() {
  const [, setUserName] = useState(localStorage.getItem('userName'));
  const { newBadge } = useGamification();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setLoading(false), 500);
  }, []);

  if (loading) return <LoadingScreen />;

  return (
    <ThemeProvider>
      <BrowserRouter>
        <ProfileModal onClose={(name) => setUserName(name)} />
        <div className="flex min-h-screen flex-col dark:bg-gray-900 dark:text-white">
          <Navbar />
          <div className="flex flex-1">
            <Sidebar />
            <AnimatedRoutes />
          </div>
        </div>
        <BadgeNotification badge={newBadge} />
      </BrowserRouter>
    </ThemeProvider>
  );
}
