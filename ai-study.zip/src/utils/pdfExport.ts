export const exportNoteToPDF = (title: string, content: string, subject: string): void => {
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;
  
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>${title}</title>
      <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; color: #333; }
        h1 { color: #1a237e; border-bottom: 2px solid #FFD600; padding-bottom: 10px; }
        .meta { color: #666; font-size: 14px; margin-bottom: 20px; }
        .content { line-height: 1.8; }
        h2 { color: #1a237e; margin-top: 20px; }
        strong { color: #1a237e; }
        ul { margin: 10px 0; padding-left: 20px; }
        @media print { body { margin: 0; } }
      </style>
    </head>
    <body>
      <h1>${title}</h1>
      <div class="meta">Subject: ${subject} | Date: ${new Date().toLocaleDateString()}</div>
      <div class="content">${content.replace(/\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/^## (.*)/gm, '<h2>$1</h2>').replace(/^- (.*)/gm, '<li>$1</li>')}</div>
      <script>window.print(); window.close();</script>
    </body>
    </html>
  `);
};
