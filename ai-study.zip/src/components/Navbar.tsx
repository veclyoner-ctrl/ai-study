import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { motion, AnimatePresence } from 'motion/react';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const userName = localStorage.getItem('userName') || 'User';
  const streak = JSON.parse(localStorage.getItem('ai-study-streak') || '{"currentStreak":0}');

  const links = [
    { name: 'Home', path: '/' },
    { name: 'AI Assistant', path: '/ai-assistant' },
    { name: 'Notes', path: '/notes' },
    { name: 'Quiz', path: '/quiz' },
    { name: 'Flashcards', path: '/flashcards' },
    { name: 'Planner', path: '/planner' },
    { name: 'Dashboard', path: '/dashboard' },
  ];

  return (
    <nav className="sticky top-0 z-40 bg-blue-700 text-white shadow-lg">
      <div className="mx-auto flex max-w-7xl items-center justify-between p-4">
        <Link to="/" className="flex items-center gap-2">
          <img src="https://cdn.phototourl.com/free/2026-09-19-6a312d96-3310-49a5-bd9c-2eb2d19d480e.png" alt="Logo" className="h-10 w-10" />
          <span className="text-xl font-bold">AI STUDY</span>
        </Link>
        <div className="hidden items-center gap-4 md:flex">
          {links.map(link => (
            <Link key={link.path} to={link.path} className="hover:text-yellow-400">{link.name}</Link>
          ))}
          <button onClick={toggleTheme} className="rounded-full p-2 hover:bg-blue-800">
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          </button>
          <div className='flex items-center gap-2'>
            {streak.currentStreak > 0 && <span className='bg-yellow-400 text-black px-2 rounded-full font-bold'>🔥 {streak.currentStreak}</span>}
            <span className="font-semibold text-yellow-400">Hi, {userName}</span>
          </div>
        </div>
        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="flex flex-col gap-2 bg-blue-800 p-4 md:hidden"
          >
            {links.map(link => (
              <Link key={link.path} to={link.path} className="hover:text-yellow-400" onClick={() => setIsOpen(false)}>{link.name}</Link>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
