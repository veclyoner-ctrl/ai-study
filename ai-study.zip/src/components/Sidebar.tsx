import { Link, useLocation } from 'react-router-dom';
import { Home, Brain, BookOpen, HelpCircle, FileText, Calendar, LayoutDashboard } from 'lucide-react';

export function Sidebar() {
  const location = useLocation();
  const links = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'AI Assistant', path: '/ai-assistant', icon: Brain },
    { name: 'Notes', path: '/notes', icon: BookOpen },
    { name: 'Quiz', path: '/quiz', icon: HelpCircle },
    { name: 'Flashcards', path: '/flashcards', icon: FileText },
    { name: 'Planner', path: '/planner', icon: Calendar },
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
  ];

  return (
    <div className="hidden h-screen w-64 bg-gray-100 p-4 shadow-lg dark:bg-gray-900 md:block">
      <div className="flex flex-col gap-2">
        {links.map(link => {
          const isActive = location.pathname === link.path;
          return (
            <Link
              key={link.path}
              to={link.path}
              className={`flex items-center gap-3 rounded-lg p-3 ${
                isActive ? 'bg-yellow-400 text-black' : 'text-gray-700 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-800'
              }`}
            >
              <link.icon size={20} />
              {link.name}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
