import React from 'react';
import { Badge } from '../types/planner';

interface Props {
  badge: Badge | null;
}

const BadgeNotification: React.FC<Props> = ({ badge }) => {
  if (!badge) return null;
  return (
    <div style={{
      position: 'fixed', bottom: '24px', right: '24px', zIndex: 9999,
      background: '#1a237e', color: '#fff', borderRadius: '12px',
      padding: '14px 18px', display: 'flex', alignItems: 'center',
      gap: '12px', boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
      animation: 'slideIn 0.3s ease',
      maxWidth: '280px'
    }}>
      <span style={{ fontSize: '32px' }}>{badge.icon}</span>
      <div>
        <div style={{ fontSize: '11px', color: '#FFD600', fontWeight: 500, marginBottom: '2px' }}>
          Naya Badge Mila! 🎉
        </div>
        <div style={{ fontSize: '14px', fontWeight: 500 }}>{badge.name}</div>
        <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>{badge.description}</div>
      </div>
    </div>
  );
};

export default BadgeNotification;
